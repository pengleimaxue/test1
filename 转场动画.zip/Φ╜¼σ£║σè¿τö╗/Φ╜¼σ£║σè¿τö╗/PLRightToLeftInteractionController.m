//
//  PLRightToLeftInteractionController.m
//  转场动画
//
//  Created by penglei on 2017/11/28.
//  Copyright © 2017年 penglei. All rights reserved.
//

#import "PLRightToLeftInteractionController.h"
#import <objc/runtime.h>

const NSString *PLGestureKey = @"PLRightToLeftGestureKey";

@interface PLRightToLeftInteractionController()

@property(nonatomic, assign) BOOL shouldCompleteTransition;
@property(nonatomic, strong) UIViewController *viewController;
@property(nonatomic, assign) PLInteractiveTransitionType type;


@end

@implementation PLRightToLeftInteractionController

- (void)insertToViewController:(UIViewController *)viewController forType:(PLInteractiveTransitionType)type {
    self.viewController = viewController;
    self.type = type;
    self.isCanRightToLeft = YES;
    [self prepareGestureRecognizerInView:viewController.view];
}

- (void)prepareGestureRecognizerInView:(UIView*)view {
    //移除之前添加的手势
    UIPanGestureRecognizer *gesture = objc_getAssociatedObject(view, (__bridge const void *)(PLGestureKey));
    
    if (gesture) {
        [view removeGestureRecognizer:gesture];
    }
    
    
    gesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleGesture:)];
    [view addGestureRecognizer:gesture];
    
    objc_setAssociatedObject(view, (__bridge const void *)(PLGestureKey), gesture,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
}

- (CGFloat)completionSpeed
{
    return 1 - self.percentComplete;
}

- (void)handleGesture:(UIPanGestureRecognizer*)gestureRecognizer {
    //手势位置
    CGPoint translation = [gestureRecognizer translationInView:gestureRecognizer.view.superview];
   
    switch (gestureRecognizer.state) {
        case UIGestureRecognizerStateBegan: {
            if (translation.x < 0 && self.isCanRightToLeft ) {
                [self startGesture];
            }
            break;
        }
        case UIGestureRecognizerStateChanged: {
            if (self.interactionInProgress) {
                // compute the current position
                CGFloat fraction = fabs(translation.x / 180.0);
                fraction = fminf(fmaxf(fraction, 0.0), 1.0);
                _shouldCompleteTransition = (fraction > 0.5);
                if (fraction >= 1.0)
                    fraction = 0.99;
                
                [self updateInteractiveTransition:fraction];
            }
            break;
        }
        case UIGestureRecognizerStateEnded:
        case UIGestureRecognizerStateCancelled:
            if (self.interactionInProgress) {
                self.interactionInProgress = NO;
                if (!_shouldCompleteTransition || gestureRecognizer.state == UIGestureRecognizerStateCancelled) {
                    [self cancelInteractiveTransition];
                }
                else {
                    [self finishInteractiveTransition];
                }
            }
            break;
        default:
            break;
    }
    
}

- (void)startGesture{
    self.interactionInProgress = YES;
    switch (_type) {
        case PLInteractiveTransitionTypePresent:{
            if (self.presentConifg) {
                self.presentConifg();
            }
        }
            break;
            
        case PLInteractiveTransitionTypeDismiss:
            [self.viewController dismissViewControllerAnimated:YES completion:nil];
            break;
        case PLInteractiveTransitionTypePush:{
            if (self.pushConifg) {
                self.pushConifg();
            }
        }
            break;
        case PLInteractiveTransitionTypePop:
            [self.viewController.navigationController popViewControllerAnimated:YES];
            break;
    }
}

@end
