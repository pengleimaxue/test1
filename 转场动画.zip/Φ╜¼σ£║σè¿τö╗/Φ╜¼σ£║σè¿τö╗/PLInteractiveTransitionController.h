//
//  PLInteractiveTransitionController.h
//  转场动画
//
//  Created by penglei on 2017/11/28.
//  Copyright © 2017年 penglei. All rights reserved.
//

#import <UIKit/UIKit.h>

//手势的方向
typedef NS_ENUM(NSUInteger, PLInteractiveTransitionGestureDirection) {
    PLInteractiveTransitionGestureDirectionLeft = 0,
    PLInteractiveTransitionGestureDirectionRight,
    PLInteractiveTransitionGestureDirectionUp,
    PLInteractiveTransitionGestureDirectionDown
};

//手势控制哪种转场
typedef NS_ENUM(NSUInteger, PLInteractiveTransitionType) {
    PLInteractiveTransitionTypePresent = 0,
    PLInteractiveTransitionTypeDismiss,
    PLInteractiveTransitionTypePush,
    PLInteractiveTransitionTypePop,
};

typedef void(^GestureConifg)();

/**
 手势管理基本类
 */
@interface PLInteractiveTransitionController : UIPercentDrivenInteractiveTransition



- (void)insertToViewController:(UIViewController*)viewController forType:(PLInteractiveTransitionType)type;

/**
 手势present的时候的config
 */
@property (nonatomic, copy) GestureConifg presentConifg;

/**
 手势push的时候的config
 */
@property (nonatomic, copy) GestureConifg pushConifg;

/**
 手势是否正在开始
 */
@property (nonatomic, assign) BOOL interactionInProgress;


@end
