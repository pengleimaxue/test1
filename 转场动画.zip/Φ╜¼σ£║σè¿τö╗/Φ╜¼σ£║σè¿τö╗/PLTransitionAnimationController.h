//
//  PLTransitionAnimationController.h
//  转场动画
//
//  Created by penglei on 2017/11/28.
//  Copyright © 2017年 penglei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/**
 控制转场动画BaseViewController
 */
@interface PLTransitionAnimationController : NSObject <UIViewControllerAnimatedTransitioning>

/**
 动画方向 是跳转还是返回
 */
@property(nonatomic, assign) BOOL reverse;

/**
    动画时间 默认 1.0f
 */
@property (nonatomic, assign) NSTimeInterval duration;

/**
 如何执行过渡动画
 @param transitionContext 动画传递协议
 @param fromVC 当前VC
 @param toVC    将要跳转到的VC
 @param fromView 当前VC的View
 @param toView  将要跳转到的VC的View
 */
- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext fromVC:(UIViewController *)fromVC toVC:(UIViewController *)toVC fromView:(UIView *)fromView toView:(UIView *)toView;

@end
