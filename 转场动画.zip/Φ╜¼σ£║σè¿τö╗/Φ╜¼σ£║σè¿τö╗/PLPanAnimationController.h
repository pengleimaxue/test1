//
//  PLPanAnimationController.h
//  转场动画
//
//  Created by penglei on 2017/11/28.
//  Copyright © 2017年 penglei. All rights reserved.
//

#import "PLTransitionAnimationController.h"

@interface PLPanAnimationController : PLTransitionAnimationController

@end
