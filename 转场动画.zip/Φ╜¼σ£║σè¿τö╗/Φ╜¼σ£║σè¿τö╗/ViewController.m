//
//  ViewController.m
//  转场动画
//
//  Created by penglei on 2017/11/28.
//  Copyright © 2017年 penglei. All rights reserved.
//

#import "ViewController.h"
#import "NavigationViewController.h"
#import "AppDelegate.h"
#import "PLTransitionAnimationController.h"
#import "PLInteractiveTransitionController.h"

@interface ViewController ()<UINavigationControllerDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
        // Do any additional setup after loading the view, typically from a nib.
    
}
- (instancetype)init{
    if (self= [super init]) {
        self.title = @"test";
        self.view.backgroundColor = [UIColor redColor];
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame =CGRectMake(80, 80, 100, 100);
        [button setTitle:@"next" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(push) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:button];
        
    }
    return self;
}
- (void)push {
    ViewController *viewController= [[ViewController alloc]init];
    [self.navigationController pushViewController:viewController animated:YES];
}

@end
