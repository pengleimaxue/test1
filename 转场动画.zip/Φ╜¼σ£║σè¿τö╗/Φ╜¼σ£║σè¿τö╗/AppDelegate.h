//
//  AppDelegate.h
//  转场动画
//
//  Created by penglei on 2017/11/28.
//  Copyright © 2017年 penglei. All rights reserved.
//

#import <UIKit/UIKit.h>

#define AppDelegateAccessor ((AppDelegate *)[[UIApplication sharedApplication] delegate])

@class PLTransitionAnimationController, PLInteractiveTransitionController;
@class CEReversibleAnimationController, CEBaseInteractionController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

//@property (strong, nonatomic) PLTransitionAnimationController *navigationControllerAnimationController;
@property (strong, nonatomic) PLInteractiveTransitionController *navigationControllerInteractionController;
//@property (strong, nonatomic) CEReversibleAnimationController *settingsAnimationController;
@property (strong, nonatomic) CEReversibleAnimationController *navigationControllerAnimationController;
//@property (strong, nonatomic) CEBaseInteractionController *navigationControllerInteractionController;
//@property (strong, nonatomic) CEBaseInteractionController *settingsInteractionController;
@end

