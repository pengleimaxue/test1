//
//  PLRightToLeftInteractionController.h
//  转场动画
//
//  Created by penglei on 2017/11/28.
//  Copyright © 2017年 penglei. All rights reserved.
//

#import "PLInteractiveTransitionController.h"

@interface PLRightToLeftInteractionController : PLInteractiveTransitionController

@property(nonatomic, assign) BOOL isCanRightToLeft;

@end
