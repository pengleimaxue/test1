//
//  PLInteractiveTransitionController.m
//  转场动画
//
//  Created by penglei on 2017/11/28.
//  Copyright © 2017年 penglei. All rights reserved.
//

#import "PLInteractiveTransitionController.h"


@implementation PLInteractiveTransitionController

- (void)insertToViewController:(UIViewController *)viewController forType:(PLInteractiveTransitionType)type {
    NSLog(@"this is Base gesture Controller,%@",[NSString stringWithFormat:@"You must override %@ in a subclass", NSStringFromSelector(_cmd)]);
}


@end
