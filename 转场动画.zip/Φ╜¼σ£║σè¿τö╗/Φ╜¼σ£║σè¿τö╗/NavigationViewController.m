//
//  NavigationViewController.m
//  转场动画
//
//  Created by penglei on 2017/11/28.
//  Copyright © 2017年 penglei. All rights reserved.
//

#import "NavigationViewController.h"
#import "AppDelegate.h"
#import "PLTransitionAnimationController.h"
#import "PLInteractiveTransitionController.h"
#import "CEBaseInteractionController.h"
#import "CEReversibleAnimationController.h"

@interface NavigationViewController ()<UINavigationControllerDelegate>

@end

@implementation NavigationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (instancetype)initWithRootViewController:(UIViewController *)rootViewController {
    self = [super initWithRootViewController:rootViewController];
    if (self) {
        self.delegate = self;
    }
    return self;
}


- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated {
    
    [self wirePopInteractionControllerTo:viewController];
}

- (void)wirePopInteractionControllerTo:(UIViewController *)viewController
{
    // when a push occurs, wire the interaction controller to the to- view controller
    if (!AppDelegateAccessor.navigationControllerInteractionController) {
        return;
    }
    
    [AppDelegateAccessor.navigationControllerInteractionController  insertToViewController:viewController forType:PLInteractiveTransitionTypePop];
}


- (id<UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController animationControllerForOperation:(UINavigationControllerOperation)operation fromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC {
    
    if (AppDelegateAccessor.navigationControllerAnimationController) {
        AppDelegateAccessor.navigationControllerAnimationController.reverse = operation == UINavigationControllerOperationPop;
    }
    
    return AppDelegateAccessor.navigationControllerAnimationController;
}

- (id <UIViewControllerInteractiveTransitioning>)navigationController:(UINavigationController *)navigationController interactionControllerForAnimationController:(id <UIViewControllerAnimatedTransitioning>) animationController {
    
    // if we have an interaction controller - and it is currently in progress, return it
    return AppDelegateAccessor.navigationControllerInteractionController && AppDelegateAccessor.navigationControllerInteractionController.interactionInProgress ? AppDelegateAccessor.navigationControllerInteractionController : nil;
    //return AppDelegateAccessor.navigationControllerInteractionController;
}
@end
